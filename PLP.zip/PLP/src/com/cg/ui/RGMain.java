package com.cg.ui;

import java.util.Scanner;

import com.cg.rg.ReportGeneration;

public class RGMain extends ReportGeneration {
	 static Scanner sc=new Scanner(System.in);
	private static String agent;
	private static String admin;
	private static String insured;


public static void details() {
	
	System.out.println("Enter the insured Name");
	String insureddName = sc.next();
	System.out.println("Enter the insured street");
	String insuredStreet=sc.next();
	System.out.println("Enter the insured city");
	String insuredCity = sc.next();
	System.out.println("Enter the insured state");
	String insuredState=sc.next();
	System.out.println("Enter the insured Zip");
	Long insuredZip=sc.nextLong();
	System.out.println("Enter the Business Segment");
	String businessSegment=sc.next();
	//System.out.println("enter the username");
	 //Object username1=sc.next();
	System.out.println("Enter the Account number");
	Long accountNumber=sc.nextLong();
	System.out.println("Enter the Agent Name");
	String agentname=sc.next();
	
}


public static void main(String[] args) {
	System.out.println("Enter the username");
	String username = sc.next();
	
	if (username.equals("agent")||username.equals("admin")) {
		
		//System.out.println("enter username");
		details();
		System.out.println(" username is"+username);
		//String username1 = sc.next();
		
	} else if(username.equals("insured")) {
		details();
		System.out.println(" username is" + username);
		
//System.out.println("enter the agentname or admin name");
		
	}
	else {
		System.out.println("out of application");
	}
	
}
}

